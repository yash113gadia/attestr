// Attestr Extension — Content Script
// Shows verification badge + info card overlays on images.
// Uses a fixed overlay container so it works on any website layout.

const OVERLAY_ID = "attestr-overlay-root";
const MIN_IMAGE_SIZE = 50;
const scannedUrls = new Set();
const imageOverlays = new Map(); // imageUrl → { badge, card, img }

// Create a single fixed overlay container for all badges
function getOverlayRoot() {
  let root = document.getElementById(OVERLAY_ID);
  if (!root) {
    root = document.createElement("div");
    root.id = OVERLAY_ID;
    root.style.cssText = "position:fixed;top:0;left:0;width:0;height:0;z-index:2147483647;pointer-events:none;";
    document.body.appendChild(root);
  }
  return root;
}

function findImageElement(src) {
  const imgs = document.querySelectorAll("img");
  for (const img of imgs) {
    if (img.src === src || img.currentSrc === src) return img;
  }
  for (const img of imgs) {
    if (src.includes(img.src) || img.src.includes(src)) return img;
  }
  return null;
}

function removeOverlay(imageUrl) {
  const existing = imageOverlays.get(imageUrl);
  if (existing) {
    existing.badge?.remove();
    existing.card?.remove();
    imageOverlays.delete(imageUrl);
  }
}

function createBadge(status) {
  const badge = document.createElement("div");

  let icon, bg;
  switch (status) {
    case "checking":
      icon = "?"; bg = "#3B82F6"; break;
    case "verified":
      icon = "\u2713"; bg = "#22C55E"; break;
    case "unverified":
      icon = "\u2717"; bg = "#EF4444"; break;
    default:
      icon = "!"; bg = "#6B7280";
  }

  badge.style.cssText = `
    position:fixed; width:26px; height:26px; border-radius:50%;
    background:${bg}; color:#fff; display:flex; align-items:center;
    justify-content:center; font-size:15px; font-weight:700;
    font-family:system-ui,sans-serif; line-height:1;
    box-shadow:0 2px 8px rgba(0,0,0,0.5); pointer-events:auto;
    cursor:pointer; transition:transform 0.15s;
    ${status === "checking" ? "animation:attestr-pulse 1.2s infinite;" : ""}
  `;
  badge.textContent = icon;
  return badge;
}

function createInfoCard(status, details) {
  const card = document.createElement("div");

  const isVerified = status === "verified";
  const isChecking = status === "checking";
  const borderColor = isVerified ? "#22C55E" : isChecking ? "#3B82F6" : "#EF4444";
  const statusText = isVerified ? "Verified on Blockchain" : isChecking ? "Checking..." : "Not Registered";
  const statusColor = isVerified ? "#22C55E" : isChecking ? "#3B82F6" : "#EF4444";

  let hashLine = "";
  if (details?.hash) {
    hashLine = `<div style="font-family:'SF Mono',Menlo,Consolas,monospace;font-size:10px;color:#6B7280;margin-top:4px;word-break:break-all;">SHA-256: ${details.hash.substring(0, 12)}...${details.hash.substring(56)}</div>`;
  }

  let timeLine = "";
  if (details?.details?.message) {
    const msg = details.details.message;
    timeLine = `<div style="font-size:10px;color:#9A9DB0;margin-top:3px;line-height:1.4;">${msg.substring(0, 100)}${msg.length > 100 ? '...' : ''}</div>`;
  }

  let networkLine = "";
  if (isVerified) {
    networkLine = `<div style="display:flex;align-items:center;gap:4px;margin-top:5px;">
      <span style="width:5px;height:5px;border-radius:50%;background:#22C55E;display:inline-block;"></span>
      <span style="font-size:9px;color:#22C55E;font-family:'SF Mono',Menlo,monospace;letter-spacing:0.5px;">ETHEREUM SEPOLIA</span>
    </div>`;
  }
  if (!isVerified && !isChecking) {
    networkLine = `<div style="font-size:10px;color:#6B7280;margin-top:4px;">This image has no blockchain registration.</div>`;
  }

  card.innerHTML = `
    <div style="display:flex;align-items:center;gap:6px;margin-bottom:4px;">
      <span style="width:8px;height:8px;border-radius:50%;background:${statusColor};flex-shrink:0;${isChecking ? 'animation:attestr-pulse 1.2s infinite;' : ''}"></span>
      <span style="font-size:12px;font-weight:600;color:${statusColor};">${statusText}</span>
    </div>
    ${hashLine}
    ${timeLine}
    ${networkLine}
    <div style="display:flex;align-items:center;gap:4px;margin-top:6px;padding-top:5px;border-top:1px solid rgba(255,255,255,0.08);">
      <svg width="10" height="10" viewBox="0 0 200 200" fill="none"><polygon points="100,10 180,46 180,154 100,190 20,154 20,46" fill="none" stroke="#3B82F6" stroke-width="12"/></svg>
      <span style="font-size:9px;color:#5C5F73;font-weight:500;">Attestr</span>
    </div>
  `;

  card.style.cssText = `
    position:fixed; z-index:2147483647;
    background:#0D0E14; border:1px solid ${borderColor}44; border-radius:8px;
    padding:10px 12px; min-width:220px; max-width:280px;
    box-shadow:0 4px 24px rgba(0,0,0,0.7);
    font-family:system-ui,-apple-system,sans-serif;
    opacity:0; transform:translateY(4px); transition:opacity 0.15s,transform 0.15s;
    pointer-events:none;
  `;

  return card;
}

function positionOverlay(imageUrl) {
  const entry = imageOverlays.get(imageUrl);
  if (!entry) return;
  const { badge, card, img } = entry;

  const rect = img.getBoundingClientRect();
  if (rect.width < 10 || rect.height < 10) {
    badge.style.display = "none";
    card.style.display = "none";
    return;
  }

  badge.style.display = "flex";
  badge.style.top = (rect.top + 6) + "px";
  badge.style.left = (rect.right - 32) + "px";

  // Position card to the left of the badge
  card.style.top = (rect.top + 6) + "px";
  card.style.left = Math.max(4, rect.right - 32 - 240) + "px";
}

function showBadge(imageUrl, status, details) {
  const img = findImageElement(imageUrl);
  if (!img) return;

  removeOverlay(imageUrl);

  const root = getOverlayRoot();
  const badge = createBadge(status);
  const card = createInfoCard(status, details);
  root.appendChild(badge);
  root.appendChild(card);

  imageOverlays.set(imageUrl, { badge, card, img });
  positionOverlay(imageUrl);

  // Show card on badge hover
  badge.addEventListener("mouseenter", () => {
    card.style.opacity = "1";
    card.style.transform = "translateY(0)";
    card.style.pointerEvents = "auto";
    badge.style.transform = "scale(1.15)";
  });
  badge.addEventListener("mouseleave", () => {
    setTimeout(() => {
      if (!card.matches(":hover")) {
        card.style.opacity = "0";
        card.style.transform = "translateY(4px)";
        card.style.pointerEvents = "none";
        badge.style.transform = "scale(1)";
      }
    }, 100);
  });
  card.addEventListener("mouseleave", () => {
    card.style.opacity = "0";
    card.style.transform = "translateY(4px)";
    card.style.pointerEvents = "none";
    badge.style.transform = "scale(1)";
  });
}

// Reposition all overlays on scroll/resize
function repositionAll() {
  for (const [url] of imageOverlays) {
    positionOverlay(url);
  }
}

window.addEventListener("scroll", repositionAll, { passive: true });
window.addEventListener("resize", repositionAll, { passive: true });

// Also reposition periodically for lazy-loaded content shifts
setInterval(repositionAll, 2000);

// Scan all visible images on the page
function scanAllImages() {
  const images = document.querySelectorAll("img");
  let count = 0;

  images.forEach((img) => {
    const src = img.currentSrc || img.src;
    if (!src || src.startsWith("data:") || src.startsWith("blob:")) return;
    if (scannedUrls.has(src)) return;
    if (img.naturalWidth < MIN_IMAGE_SIZE || img.naturalHeight < MIN_IMAGE_SIZE) return;

    scannedUrls.add(src);
    count++;

    showBadge(src, "checking", null);

    chrome.runtime.sendMessage(
      { type: "ATTESTR_VERIFY_IMAGE", imageUrl: src },
      (response) => {
        if (chrome.runtime.lastError) {
          showBadge(src, "error", null);
          return;
        }
        if (response?.ok) {
          showBadge(src, response.result.status, response.result);
        } else {
          showBadge(src, "error", null);
        }
      }
    );
  });

  return count;
}

// Listen for messages from background
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "ATTESTR_STATUS") {
    showBadge(msg.imageUrl, msg.status, null);
  } else if (msg.type === "ATTESTR_RESULT") {
    showBadge(msg.imageUrl, msg.status || "error", msg);
  } else if (msg.type === "ATTESTR_SCAN_ALL") {
    const count = scanAllImages();
    sendResponse({ count });
  }
});
